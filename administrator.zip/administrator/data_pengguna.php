<?php
include "header.php";
include "navbar.php";
?>
<div class="card mt-2">
	<div class="card-body text-center">
		<h1>Selamat Datang Di Halaman administrator</h1>
	</div>
</div>
<?php
include "footer.php";
?>
