<?php
include "header.php";
include "navbar.php";
?>
<div class="card mt-2">
    <div class="card-body">
        <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#tambah-data">
            Tambah Data
        </button>
        <table class="table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Id Pelanggan</th>
                    <th>Nama Pelanggan</th>
                    <th>Alamat</th>
                    <th>Total Pembayaran</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include '../koneksi.php';
                $no = 1;
                $data = mysqli_query($koneksi, "SELECT * FROM pelanggan INNER JOIN penjualan ON pelanggan.PelangganID=penjualan.PelangganID");
                while ($d = mysqli_fetch_array($data)) {
                ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo $d['PelangganID']; ?></td>
                        <td><?php echo $d['NamaPelanggan']; ?></td>
                        <td><?php echo $d['NomorTelepon']; ?></td>
                        <td><?php echo $d['Alamat']; ?></td>
                        <td>Rp. <?php echo $d['TotalHarga']; ?></td>

                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>
<!-- Modal Tambah Data -->
<div class="modal fade" id="tambah-data" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Data</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="proses_simpan_barang.php" method="post">
                <div class="modal-body">
                    <div class="form-grup">
                        <label>Id Pelanggan</label>
                        <input type="text" name="PelangganID" value="<?php echo date("dmY") ?>" class="form-control">
                    </div>
                    <div class="form-grup">
                        <label>Harga Produk</label>
                        <input type="number" name="Harga" class="form-control">
                    </div>
                    <div class="form-grup">
                        <label>Stok Produk</label>
                        <input type="number" name="Stok" class="form-control">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keluar</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php
include "footer.php";
?>