<?php
include "header.php";
include "navbar.php";
?>

<div class="card mt-2">
    <div class="card-body">
        <?php
        include '../koneksi.php';
        $PelangganID = $_GET['PelangganID'];
        $no = 1;
        $data = mysqli_query($koneksi, "SELECT * FROM pelanggan INNER JOIN penjualan ON pelanggan.PelangganID=penjualan.PelangganID");
        while ($d = mysqli_fetch_array($data)) {
        ?>
            <?php if ($d['PelangganID'] == $PelangganID) { ?>
                <table>
                    <tr>
                        <td>ID Pelanggan</td>
                        <td>: <?php echo $d['PelangganID']; ?></td>
                    </tr>
                    <tr>
                        <td>Nama Pelanggan</td>
                        <td>: <?php echo $d['NamaPelanggan']; ?></td>
                    </tr>
                    <tr>
                        <td>No. Telepon</td>
                        <td>: <?php echo $d['NomorTelepon']; ?></td>
                    </tr>
                    <tr>
                        <td>Alamat</td>
                        <td>: <?php echo $d['Alamat']; ?></td>
                    </tr>
                    <tr>
                        <td>Total Pembelian</td>
                        <td>: <?php echo $d['TotalHarga']; ?></td>
                    </tr>
                </table>
                <button type="button" class="btn btn-primary btn-sm mt-2" data-bs-toggle="modal" data-bs-target="#tambah-data">
                    Tambah Barang
                </button>
                <table class="table">
                    <thead>
                        <th>
                            <tr>
                                <th>No</th>
                                <th>Nama Produk</th>
                                <th>Jumlah Beli</th>
                                <th>Total Harga</th>
                                <th>Aksi</th>
                            </tr>
                        </th>
                    </thead>
                    <tbody>
                        <?php
                        include '../koneksi.php';
                        $no = 1;
                        $detailpenjualan = mysqli_query($koneksi, "SELECT * FROM detailpenjualan INNER JOIN penjualan ON detailpenjualan.PenjualanID=penjualan.PenjualanID INNER JOIN produk ON detailpenjualan.ProdukID=produk.ProdukID");
                        while ($d_detailpenjualan = mysqli_fetch_array($detailpenjualan)) {
                        ?>
                            <?php
                            if ($d_detailpenjualan['PenjualanID'] == $d['PenjualanID']) { ?>
                                <tr>
                                    <td><?php echo $d_detailpenjualan['NamaProduk']; ?></td>
                                    <td><?php echo $d_detailpenjualan['JumlahProduk']; ?></td>
                                    <td><?php echo $d_detailpenjualan['SubTotal']; ?></td>
                                </tr>
                            <?php  } else {
                            ?>
                        <?php
                            }
                        }
                        ?>
                    </tbody>
                </table>

                <!-- Modal Tambah Data-->
                <div class="modal fade" id="tambah-data" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Barang</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form action="proses_pembelian.php" method="post">
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label>Nama Produk</label>
                                        <input type="hidden" name="PenjualanID" value="<?php echo $d['PenjualanID']; ?>">
                                        <select name="ProdukID" class="form-control">
                                            <?php
                                            include '../koneksi.php';
                                            $produk = mysqli_query($koneksi, "SELECT * FROM produk ");
                                            while ($d_produk = mysqli_fetch_array($produk)) {
                                            ?>
                                                <option value="<?php echo $d_produk['ProdukID']; ?>"><?php echo $d_produk['NamaProduk']; ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Jumlah Beli</label>
                                        <input type="text" name="JumlahProduk" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>No. Telepon</label>
                                        <input type="text" name="NomorTelepon" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Alamat</label>
                                        <input type="text" name="Alamat" class="form-control">
                                        <input type="hidden" name="TanggalPenjualan" value="<?php echo date("Y-m-d") ?>" class="form-control">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keluar</button>
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php } else { ?>
        <?php
            }
        }
        ?>
    </div>
</div>
<?php
include "footer.php";
?>