<?php
include "header.php";
include "navbar.php";
?>

<div class="card mt-2">
    <div class="card-body">
        <table>
            <?php
            include '../koneksi.php';
            $PelangganID = $_GET['PelangganID'];
            $no = 1;
            $data = mysqli_query($koneksi, "SELECT * FROM pelanggan INNER JOIN penjualan ON pelanggan.PelangganID=penjualan.PelangganID");
            while ($d = mysqli_fetch_array($data)) {
            ?>
                <tr>
                    <td>ID Pelanggan</td>
                    <td>: <?php echo $d['PelangganID']; ?></td>
                </tr>
                <tr>
                    <td>Nama Pelanggan</td>
                    <td>: <?php echo $d['NamaPelanggan']; ?></td>
                </tr>
                <tr>
                    <td>Nama Pelanggan</td>
                    <td>: <?php echo $d['NamaPelanggan']; ?></td>
                </tr>
                <tr>
                    <td>Nama Pelanggan</td>
                    <td>: <?php echo $d['NamaPelanggan']; ?></td>
                </tr>
                <tr>
                    <td>Nama Pelanggan</td>
                    <td>: <?php echo $d['NamaPelanggan']; ?></td>
                </tr>
            <?php } ?>
        </table>
    </div>
</div>

<?php
include "footer.php";
?>